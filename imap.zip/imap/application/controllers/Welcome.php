<?php
/**
 * Imap Class
 * This class enables you to use the IMAP Protocol
 *
 * @package    CodeIgniter
 * @subpackage Libraries
 * @category   Email
 * @version    1.0.0-dev
 * @author     Natan Felles
 * @link       http://github.com/natanfelles/codeigniter-imap
 */

defined('BASEPATH') || exit('No direct script access allowed');

/**
 * Class Imap
 */
class Welcome extends CI_Controller {
        

        // IMAP/POP3 (mail server) LOGIN
    //    var $imap_server      = 'imap.gmail.com/imap/ssl';
    //    var $imap_server      = 'imap.gmail.com';
        var $imap_server      = 'imap.gmail.com';
        var $imap_user        = ''; // enter user mail_id 
        var $imap_pass        = ''; // enter user password

    
        // Constuctor
        
        function __construct() {



        //    parent::Controller();
            parent::__construct();
            //echo "test";
            $this->load->helper('url');
            $this->load->database();
            $this->config->load('Imap');
            $this->load->library('Imap');

             
                        
        }

        // index
        
        function index() {
        //    echo "test";
            $inbox = $this->imap->connect();
          //   $aaa = $this->imap->search();
          //  print_r();
           /* $data_array['totalmsg']    = $this->imap->cimap_num_msg($inbox);
            $data_array['quota']    = $this->imap->cimap_get_quota($inbox);
            
            $this->load->view('mail_view', $data_array);  */


           $data_array['mailmsg']    = $aaa = $this->imap->search();;

           $this->load->view('test', $data_array);
            // foreach ($aaa as $value) {
            //      # code...
                
            //   $varr =   $this->imap->get_message($value);
            //   echo "<br/>";
            //   print_r($varr);
            //  } 
    }
        function details_view(){
            //echo "test";
            $this->load->view('details_view');

        }

}



