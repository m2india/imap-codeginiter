<?php
$url_id = $this->input->get('id', TRUE);
//echo $url_id;
?>


<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
	<title>Details</title>
</head>
<body>

<?php

$user =$this->db->select('*')->where('uid', $url_id)->from('save_data')->get()->row_array();

//print_r($user);
?>

<div class="container-sm">
	<div class="card">
	  <div class="card-header">
	    <h1 style="text-align: center;">Mail Details</h1>
	  </div>
	  <div class="card-body">
	    <h5 class="card-title">From : <?php echo $user['from_email']; ?> </h5>
	    <p class="card-text">Subject: <?php echo $user['subject']; ?></p>
	    <p class="card-text">Received Date: <?php echo $user['received_date']; ?></p>
	    <a href="<?php echo base_url();?>Welcome" class="btn btn-primary">Go Back</a>
	  </div>
	</div>


<?php

?>


</div>
</body>
</html>	



