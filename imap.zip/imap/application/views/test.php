<?php

//echo "test";

 // print_r($mailmsg);

error_reporting(0);

?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
	<title></title>
</head>
<body>


<div class="container-sm">


	<h1 style="text-align: center;">From Gmail</h1>

<table class="table">
  <thead>
    <tr>
      <th scope="col">S.no</th>
      <th scope="col">From</th>
      <th scope="col">Subject</th>
      <th scope="col">View</th>
    </tr>
  </thead>
<?php


	//$varr =array();

	$i = 0;

      foreach ($mailmsg as $value) {
                
              $varr =   $this->imap->get_message($value);
          //    echo "<br/>";
        //    print_r($varr); 
        //    echo $varr ['read'];
        //    die();

              $date = $varr ['date'];

              $timestamp = strtotime($date);

              $mail_current_date = date("d-m-Y", $timestamp);

          	  $today_current_date =  date("d-m-Y");

          	  $i++;

         	 if( $mail_current_date == $today_current_date )
         	 {
?>         	 	

  <tbody>
    <tr>
      <th scope="row"><?php echo $i; ?></th>
      <td><?php echo $varr ['from']['email']; ?></td>
      <td><?php echo $varr['subject']; ?></td>
      <td><a href="<?php echo base_url();?>Welcome/details_view?id=<?php echo $varr['uid']; ?> ">Details</a></td>
    </tr>

<?php				
    }
//             die();
          	  $user =$this->db->select('uid')->where('uid', $varr['uid'])->from('save_data')->get()->result_array();

          	 if($user[0]['uid']  != $varr['uid']){ 

              if($varr ['read'] != 1  && $mail_current_date == $today_current_date ){

					$mailmsg = array(
					'uid' => $varr['uid'],
					'subject' => $varr['subject'],
					'from_email' => $varr ['from']['email'],
					'received_date' => $varr ['date']
					);

					$data_inserted = $this->db->insert('save_data', $mailmsg);

					if($data_inserted){
					echo "<br/>";
					echo "data inserted";
					}else{
					echo "<br/>";
					//	echo "not inserted";
					}
              }

			}
	}
?>

  </tbody>
</table>
 


</div>
</body>
</html>